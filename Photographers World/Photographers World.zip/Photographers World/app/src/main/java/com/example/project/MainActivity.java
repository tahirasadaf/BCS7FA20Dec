package com.example.project;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.About.About;
import com.example.project.DataBaseWork.DatabaseHelper;

public class MainActivity extends AppCompatActivity {
    public TextView tvfor , tvNotUser;
    public Button btn1;
    public EditText uEmail, uPassword;
    private ImageView img3Dots;
    private DatabaseHelper databaseHelper;

    // public CheckBox checkBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getSupportActionBar().hide();

        initialize();
        callListeners();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = new MenuInflater(this);
        getMenuInflater().inflate(R.menu.threedots, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.about) {
            Intent it = new Intent(MainActivity.this , About.class);
            startActivity(it);

        } else {

        }
        return super.onOptionsItemSelected(item);
    }

    private void callListeners() {

        img3Dots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(MainActivity.this, img3Dots);
                final Menu menu = popup.getMenu();

                popup.getMenuInflater().inflate(R.menu.threedots, popup.getMenu());
                //popup.setOnMenuItemClickListener(new OverflowMenuHandler());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId())
                        {
                            case R.id.about:
                                Intent it = new Intent(MainActivity.this, About.class);
                                startActivity(it);
                                return true;
                        }


                        return false;
                    }
                });


                popup.show();

            }
        });


        tvfor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(MainActivity.this, forgetpassword.class);
                startActivity(in);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String  email= uEmail.getText().toString();
                String pass = uPassword.getText().toString();

//                && (Patterns.EMAIL_ADDRESS.matcher(email).matches))
                if(TextUtils.isEmpty(email))
                {
                    uEmail.setError("Please Fill The Fields");
                }
                else if ((!Patterns.EMAIL_ADDRESS.matcher(email).matches()))
                {
                    uEmail.setError("Please Provide Proper Email");
                }
                else if (TextUtils.isEmpty(pass))
                {
                    uPassword.setError("Please Fill The Fields");

                }
                else
                {
                    /*
                    String pass_from_db = databaseHelper.Login(email);
                    if(pass.equals(pass_from_db))
                    {
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    }

                     */



                    Intent i = new Intent(MainActivity.this, homepage.class);
                    i.putExtra("email", email);
                    i.putExtra("password", pass);
                    startActivity(i);
                    Toast.makeText(MainActivity.this, "Logged In", Toast.LENGTH_SHORT).show();


                }

            }
        });

        tvNotUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Signup.class);
                startActivity(i);

            }
        });

/*
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked)
                {
                    uPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else
                {
                    uPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }

            }
        });


 */

    }

    private void initialize() {

        uEmail = findViewById(R.id.etEmail);
        uPassword = findViewById(R.id.etPassword);
        tvNotUser = findViewById(R.id.tvNotUser);
        btn1 = findViewById(R.id.button);
        tvfor=findViewById(R.id.textView7);
      //  checkBox = findViewById(R.id.checkbox);
        img3Dots = findViewById(R.id.threeDots);
        databaseHelper = new DatabaseHelper(MainActivity.this);
    }

}