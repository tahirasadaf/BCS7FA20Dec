package com.example.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.project.Customer.CustomerHomePage;
import com.example.project.Photographer.PhotographerHomePage;
import com.example.project.Rental.RentalHomePage;

public class homepage extends AppCompatActivity {

    private Button btnPhotographer, btnCustomers, btnRentals ;

    private String emailFromMain;
    private TextView tvEmail, tvPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        getSupportActionBar().hide();

        initialize();
        getValues();
        callListeners();
    }

    private void callListeners() {



        btnPhotographer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), PhotographerHomePage.class);
                startActivity(i);
            }
        });

        btnCustomers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), CustomerHomePage.class);
                startActivity(i);
            }
        });

        btnRentals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RentalHomePage.class);
                startActivity(i);
            }
        });

    }

    private void getValues() {
        Bundle bundle = getIntent().getExtras();

        emailFromMain = bundle.get("email").toString() ;


        tvEmail.setText(emailFromMain);


    }

    private void initialize() {
        tvEmail = findViewById(R.id.textView6);
        btnPhotographer = findViewById(R.id.btnPhotographer);
        btnCustomers = findViewById(R.id.btnCustomer);
        btnRentals = findViewById(R.id.btnRental);

    }


    public void Back(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }
}