package com.example.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.example.project.About.About;

public class forgetpassword extends AppCompatActivity {
    private Button btn1;
    private Button btnBack;

    private ImageView img3Dots;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpassword);

        //getSupportActionBar().setTitle("Forget Password");
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayShowHomeEnabled(true);

        getSupportActionBar().hide();

        initialize();
        callListeners();







    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = new MenuInflater(this);
        getMenuInflater().inflate(R.menu.threedots, menu);
        return super.onCreateOptionsMenu(menu);
    }


    public boolean onOptionsItemSelected(MenuItem item){
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(myIntent);
        return true;
    }

    private void callListeners() {

        img3Dots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(forgetpassword.this , img3Dots);
                final Menu menu = popup.getMenu();

                popup.getMenuInflater().inflate(R.menu.threedots, popup.getMenu());
                //popup.setOnMenuItemClickListener(new OverflowMenuHandler());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId())
                        {
                            case R.id.about:
                                Intent it = new Intent(forgetpassword.this, About.class);
                                startActivity(it);
                                return true;
                        }


                        return false;
                    }
                });


                popup.show();

            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(forgetpassword.this,MainActivity.class);
                startActivity(in);
            }
        });


    }

    private void initialize() {
        btn1=findViewById(R.id.button);
btnBack = findViewById(R.id.btnBack);
        img3Dots = (ImageView) findViewById(R.id.threeDots);
    }
}