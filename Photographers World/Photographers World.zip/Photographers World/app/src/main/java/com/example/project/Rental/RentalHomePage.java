package com.example.project.Rental;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.project.R;

public class RentalHomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rental_home_page);

        getSupportActionBar().hide();

    }
}