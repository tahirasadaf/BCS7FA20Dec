package com.example.project.DataBaseWork;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String db_name = "db_users";
    public static final String tb_name = "tb_users";
    public static final int db_version = 1;
    private SQLiteDatabase sqLiteDatabase;


    public DatabaseHelper(@Nullable Context context) {
        super(context, db_name, null, db_version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE IF NOT EXISTS " + tb_name + "(user_id INTEGER PRIMARY KEY AUTOINCREMENT,  user_fullName VARCHAR , user_userName VARCHAR ,user_email VARCHAR , user_password VARCHAR)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + tb_name);
        onCreate(db);

    }

    public long SignUp(String email, String fullName, String userName, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("user_fullName", fullName);
        contentValues.put("user_userName", userName);
        contentValues.put("user_email", email);
        contentValues.put("user_password", password);

        sqLiteDatabase = this.getWritableDatabase();
        long result = sqLiteDatabase.insert(tb_name, null, contentValues);
        return result;

    }


    public String Login(String email) {
        sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.query(tb_name, null, "user_email=?", new String[]{email}, null, null, null);

        if (cursor.getCount()<1)
        {
            cursor.close();
            return "No Data Found";
        }
        else
        {
            cursor.moveToNext();

            String pass = cursor.getString(cursor.getColumnIndex("user_password"));
            return pass;
        }


    }

}
