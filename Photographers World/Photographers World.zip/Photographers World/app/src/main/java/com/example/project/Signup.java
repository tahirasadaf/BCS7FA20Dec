package com.example.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.About.About;
import com.example.project.DataBaseWork.DatabaseHelper;

public class Signup extends AppCompatActivity {

    public Button btn;
    TextView tv1;
    public EditText fName, uName, uEmail, uPassword, rPassword;

    private Button btnBack;

    private ImageView img3Dots;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //getSupportActionBar().setTitle("Sign Up");


        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().hide();

        initialize();
        callListeners();

    }

    public boolean onOptionsItemSelected(MenuItem item){
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(myIntent);
        return true;
    }


    private void callListeners() {


        img3Dots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(Signup.this, img3Dots);
                final Menu menu = popup.getMenu();

                popup.getMenuInflater().inflate(R.menu.threedots, popup.getMenu());
                //popup.setOnMenuItemClickListener(new OverflowMenuHandler());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId())
                        {
                            case R.id.about:
                                Intent it = new Intent(Signup.this, About.class);
                                startActivity(it);
                                return true;
                        }


                        return false;
                    }
                });


                popup.show();

            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(Signup.this,MainActivity.class);
                startActivity(in);
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String frName= fName.getText().toString();
                String UrName = uName.getText().toString();
                String email = uEmail.getText().toString();
                String userPass = uPassword.getText().toString();
                String repeatPass = rPassword.getText().toString();

//                && (Patterns.EMAIL_ADDRESS.matcher(email).matches))
                if(TextUtils.isEmpty(frName))
                {
                    fName.setError("Please Fill The Fields");
                }
                else if (TextUtils.isEmpty(UrName))
                {
                    uName.setError("Please Fill The Fields");

                }
                else if (TextUtils.isEmpty(email))
                {
                    uEmail.setError("Please Fill The Fields");
                }
                else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
                {
                    uEmail.setError("Please Provide Proper Email");
                }
                else if (TextUtils.isEmpty(userPass))
                {
                    uPassword.setError("Please Fill The Fields");

                }
                else if (TextUtils.isEmpty(repeatPass))
                {
                    rPassword.setError("Please Fill The Fields");
                }
                else if (!userPass.equals(repeatPass))
                {
                    rPassword.setError("Password did not match");
                }
                else
                {

                    if(databaseHelper.SignUp(frName , UrName , email , userPass) == -1)
                    {
                        Toast.makeText(Signup.this, "Sign Up Failed", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(Signup.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                    }


                   /* Intent i = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(i);
                    Toast.makeText(Signup.this, "Account Created", Toast.LENGTH_SHORT).show();

                    */
                }

            }
        });
    }

    private void initialize() {
        tv1=findViewById(R.id.textView3);
        fName = findViewById(R.id.fullName);
        uName = findViewById(R.id.userName);
        uEmail = findViewById(R.id.etEmail);
        uPassword = findViewById(R.id.usPassword);
        rPassword = findViewById(R.id.rePassword);
        btn = findViewById(R.id.btns);
        btnBack = findViewById(R.id.btnBack);
        img3Dots = (ImageView) findViewById(R.id.threeDots);
        databaseHelper = new DatabaseHelper(this);
    }
}