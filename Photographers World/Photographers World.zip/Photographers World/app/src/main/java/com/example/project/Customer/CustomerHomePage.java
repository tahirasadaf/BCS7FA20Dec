package com.example.project.Customer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.project.R;

public class CustomerHomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home_page);

        getSupportActionBar().hide();
    }
}