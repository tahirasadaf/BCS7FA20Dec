Rails.application.routes.draw do
  root 'pages#home'
  get 'goals' , to: 'pages#goals'
  get 'display' , to: 'pages#display'
  get 'home' , to:'pages#home'
end
