class PagesController < ApplicationController
    def home
    end

    def goals
    end

end
