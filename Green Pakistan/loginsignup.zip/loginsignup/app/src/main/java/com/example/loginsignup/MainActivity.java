package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    Button btnSignIn;
    EditText emailId,password;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    private static final int TIME_INTERVAL=2000;
    private long backPressed;
    TextView textView;





    @Override

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirebaseAuth = FirebaseAuth.getInstance();
        emailId = findViewById(R.id.email1);
        password = findViewById(R.id.pass1);
        btnSignIn = findViewById(R.id.login);

        mAuthStateListener=new FirebaseAuth.AuthStateListener() {

            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser=mFirebaseAuth.getCurrentUser();
                if (mFirebaseUser !=null){
                Toast.makeText(MainActivity.this,"you are loggedin",Toast.LENGTH_SHORT).show();
                Intent i=new Intent(MainActivity.this,home1.class);
                startActivity(i);

                }
                else {
                    Toast.makeText(MainActivity.this,"pleaselogin",Toast.LENGTH_SHORT).show();
                }
            }
            };
         btnSignIn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String email = emailId.getText().toString();
                 String pwd = password.getText().toString();
                 if (email.isEmpty()) {

                     emailId.setError("please enter email id");
                     emailId.requestFocus();
                 } else if (pwd.isEmpty()) {
                     password.setError("please enter password");
                     password.requestFocus();
                 } else if (email.isEmpty() && pwd.isEmpty()) {
                     Toast.makeText(MainActivity.this, "Fields are empty", Toast.LENGTH_SHORT).show();
                 } else if (!(email.isEmpty() && pwd.isEmpty())) {
                    mFirebaseAuth.signInWithEmailAndPassword(email,pwd).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(MainActivity.this, "LoginError", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Intent inToHome=new Intent(MainActivity.this,home1.class);
                                startActivity(inToHome);
                            }
                        }
                    });
                 }
                 else{
                     Toast.makeText(MainActivity.this,"signupunsucessful",Toast.LENGTH_SHORT).show();
                 }
             }
         });



    };


    @Override
    public void onBackPressed(){
        if(backPressed + TIME_INTERVAL > System.currentTimeMillis()){
            super.onBackPressed();
            return;
        }
        else{
            Toast.makeText(getBaseContext(),"press back again to exit",Toast.LENGTH_SHORT).show();
        }
        backPressed = System.currentTimeMillis();

    }



    public void move(View view) {
        Intent intent = new Intent(this, signup.class);

        startActivity(intent);
    }
    public void moe(View view) {
        Intent intentm = new Intent(this, home1.class);

        startActivity(intentm);
    }


    public void forget(View view) {
        Intent intentm = new Intent(this, Forget_activity.class);

        startActivity(intentm);
    }
}