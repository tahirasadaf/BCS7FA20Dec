package com.example.loginsignup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class home1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home1);
    }


    public void plantinfo(View view) {
        Intent intent =new Intent(home1.this,Plantinfo_activity.class);
        startActivity(intent);

    }

    public void profile(View view) {
        Intent intent =new Intent(home1.this,Profile_Activity.class);
        startActivity(intent);
    }

    public void green(View view) {
        Intent intent =new Intent(home1.this,Green_Activity.class);
        startActivity(intent);

    }

    public void reminder(View view) {

        Intent intent =new Intent(home1.this,Reminder_activity.class);
        startActivity(intent);

    }

    public void weather(View view) {

        Intent intent =new Intent(home1.this,Weatherinfo_activity.class);
        startActivity(intent);

    }






    public void complain(View view) {

        Intent intent =new Intent(home1.this,Complain_activity.class);
        startActivity(intent);
    }

    public void ask(View view) {
        Intent intent =new Intent(home1.this,Askplant_activity.class);
        startActivity(intent);
    }

    public void plantnn(View view) {
        Intent intent =new Intent(home1.this,Plantnow_activity.class);
        startActivity(intent);

    }
}